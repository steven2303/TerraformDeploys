import json
import boto3
import os
from pprint import pprint

def lambda_handler(event, context):
    # TODO implement
    # Origen: s3://ue1stgdesaas3ftp001/RAW-SFTP/LOGS/AUDIT_LOG/DELTA/
    # Destino: s3://ue1stgprdas3log001/LOGS/AUDIT_LOG/DELTA/
    bucket_to = os.environ.get('BUCKET_TO')
    key_to_log = os.environ.get('KEY_TO_LOG')
    key_to_master = os.environ.get('KEY_TO_MASTER')
    
    s3 = boto3.resource('s3')
    
    if "Records" in event:
        for record in event['Records']:
            if "s3" in record and 'object' in record['s3'] and 'key' and record['s3']['object']:
                
                key_from = record['s3']['object']['key']
                print(key_from)
                #RAW-SFTP/LOGS/AUDIT_LOG/DELTA/L240109.001
                if 'AUDIT_LOG' in key_from:
                    key_to = key_to_log
                else: 
                    key_to = key_to_master
                key_to = key_to  + "/".join(key_from.split("/")[-1:])
                print(key_to)
                #LOGS/AUDIT_LOG/DELTA/L240109.001

                bucket_from = record['s3']['bucket']['name']
                #ue1stgdesaas3ftp001

                #Que sea por parametro deacuerdo al ambiente
                bucket_to = bucket_to#'ue1stgprdas3log001'
                
                #s3://ue1stgprdas3log001/LOGS/AUDIT_LOG/DELTA/L240101.001
                copy_source = {
                      'Bucket': bucket_from,
                      'Key': key_from
                    }
                bucket = s3.Bucket(bucket_to)
                bucket.copy(copy_source, key_to)
                    
                    
                    
    return {
        'statusCode': 200,
        'body': json.dumps('Hello from Lambda!')
    }
