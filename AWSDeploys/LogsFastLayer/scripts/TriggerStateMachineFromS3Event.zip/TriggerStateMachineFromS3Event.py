import json
import boto3
import os

def lambda_handler(event, context):
    # Initialize the Step Functions and SQS clients
    sfn_client = boto3.client('stepfunctions')
    sqs_client = boto3.client('sqs')

    # Define the ARN of your State Machine
    state_machine_arn = os.environ.get('STATE_MACHINE_ARN')
    log_destination = os.environ.get('LOG_DESTINATION')
    error_destination = os.environ.get('ERROR_DESTINATION')

    # URL of the SQS queue
    sqs_queue_url = os.environ.get('SQS_QUEUE_URL')

    print("event", event)
    # Process each record in the SQS message
    for record in event['Records']:
        print("record", record)
        # The S3 event data is stored as a JSON string in the 'body' field
        s3_event_data = json.loads(record['body'])
        print("s3_event_data", s3_event_data)
        # Extract bucket name and file (object) name from the S3 event data
        bucket_name = s3_event_data['Records'][0]['s3']['bucket']['name']
        file_name = s3_event_data['Records'][0]['s3']['object']['key']

        # Create a dictionary to pass as input to the state machine
        state_machine_input = {
            "bucket_name": bucket_name,
            "file_name": file_name,
            "log_destination": log_destination,
            "error_destination": error_destination,
        }

        # Start the execution of the state machine
        response = sfn_client.start_execution(
            stateMachineArn=state_machine_arn,
            input=json.dumps(state_machine_input)
        )

        print(f"Started state machine execution: {response['executionArn']}")

        # Delete the message from the SQS queue
        sqs_client.delete_message(
            QueueUrl=sqs_queue_url,
            ReceiptHandle=record['receiptHandle']
        )

    return {
        'statusCode': 200,
        'body': json.dumps('State machine triggered successfully.')
    }
