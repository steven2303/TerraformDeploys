import pandas as pd
import boto3
import io
import os

def lambda_handler(event, context):
    # TODO implement
    # Origen: s3://ue1stgdesaas3ftp001/RAW-SFTP/LOGS/AUDIT_LOG/DELTA/
    # Destino: s3://ue1stgprdas3log001/LOGS/AUDIT_LOG/DELTA/
    location_to = os.environ.get('LOCATION_TO')
    
    s3_client = boto3.client('s3')
    
    if "Records" in event:
        for record in event['Records']:
            if "s3" in record and 'object' in record['s3'] and 'key' and record['s3']['object']:
                source_bucket = record['s3']['bucket']['name']
                key = record['s3']['object']['key']

                # Define the destination bucket and key
                destination_bucket = location_to.replace("s3://",'').split('/')[0]
                destination_key = location_to.replace("s3://",'').replace(destination_bucket+'/','') + "pgm_master.parquet"

                # Get the object from the event and show its content type
                response = s3_client.get_object(Bucket=source_bucket, Key=key)
                contents = response['Body'].read().decode('latin1')
                
                # Read the content into a pandas DataFrame
                data = pd.read_csv(io.StringIO(contents), encoding='latin1', header=None, sep=';')
                
                # Process the data
                data["cod_pgm"] = data[0].str[:16].str.strip()
                data["des_pgm"] = data[0].str[16:].str.strip()
                data = data[data.cod_pgm != ''].drop(columns=[0])
                
                # Write the DataFrame to a parquet file
                buffer = io.BytesIO()
                data.to_parquet(buffer, index=False)
                buffer.seek(0)
                
                # Upload the parquet file to the destination bucket
                s3_client.upload_fileobj(buffer, destination_bucket, destination_key, ExtraArgs={'ContentType': 'application/vnd.apache.parquet'})
                    
    return {
        'statusCode': 200,
        'body': f'Successfully processed {key} from {source_bucket} and uploaded to {destination_bucket}/{destination_key}'
    }
