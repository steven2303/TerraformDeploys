import boto3
import json

def lambda_handler(event, context):
    # Initialize the Glue client
    glue_client = boto3.client('glue')
    print(event)

    # Retrieve the Glue job name and run ID from the event
    job_name = event['JobName']
    run_id = event['JobRunId']

    try:
        # Get the job run details
        response = glue_client.get_job_run(JobName=job_name, RunId=run_id)
        job_run = response['JobRun']

        # Check the job run status
        status = job_run['JobRunState']

        # Return the status
        return {
            'JobName':job_name,
            'JobRunId':run_id,
            'statusCode': 200,
            'body': json.dumps('Job Status: ' + status),
            'status': status  # Include the status in the response for Step Functions
        }

    except Exception as e:
        print(e)
        return {
            'statusCode': 500,
            'body': json.dumps('Error checking job status')
        }