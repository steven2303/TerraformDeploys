import nltk
import pickle
nltk.data.path.append("/var/task/nltk_data/")
from nltk.stem import SnowballStemmer
from nltk.corpus import stopwords
import boto3
import pickle
import io
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import linear_kernel
import re
import csv
import os

# Definir stop words en español
stemmer = SnowballStemmer('spanish')
spanish_stop_words = stopwords.words('spanish')
spanish_stop_words.extend(['&', 'kg', 'lt', '-', 'ml', 'on', 'li', 'l', 'x'])

def custom_tokenizer(text):
    tokens = re.findall(r'\b\w+\b', text.lower()) 
    stemmed_tokens = [stemmer.stem(re.sub(r'\d+', '', token)) for token in tokens if token not in spanish_stop_words]
    stemmed_tokens = [token for token in stemmed_tokens if token]
    return stemmed_tokens

def fit_vectorizer(catalogo_sku):
    combined_texts = []
    for row in catalogo_sku:
        producto = row['PRODUCTO']
        categoria = row['CATEGORIA']
        combined_text = f"{producto} {categoria}"
        combined_texts.append(combined_text)
    vectorizer = TfidfVectorizer(tokenizer=custom_tokenizer, stop_words=spanish_stop_words)
    vectorizer.fit(combined_texts)
    return vectorizer

def read_csv_to_dict(bucket_name, object_key, encoding='latin1', delimiter=';'):
    s3 = boto3.client('s3')
    response = s3.get_object(Bucket=bucket_name, Key=object_key)
    csv_data = io.BytesIO(response['Body'].read())
    csv_reader = csv.DictReader(io.TextIOWrapper(csv_data, encoding=encoding), delimiter=delimiter)
    data = [row for row in csv_reader]
    return data

def save_vectorizer_to_s3(vectorizer, bucket_name, object_key):
    s3 = boto3.client('s3')
    pickle_bytes = pickle.dumps(vectorizer)
    pickle_buffer = io.BytesIO(pickle_bytes)
    s3.upload_fileobj(pickle_buffer, bucket_name, object_key)
    print(f"El vectorizer se ha guardado correctamente en el bucket '{bucket_name}' con la clave '{object_key}'.")


def lambda_handler(event, context):
    resources_bucket_name = os.environ.get('RESOURCES_BUCKET_NAME')
    data_bucket_name = os.environ.get('DATA_BUCKET_NAME')
    prefix_sku_catalog = os.environ.get('PREFIX_SKU_CATALOG')
    prefix_processing_artifacts = os.environ.get('PREFIX_PROCESSING_ARTIFACTS')
    catalogo_sku = read_csv_to_dict(data_bucket_name, prefix_sku_catalog)
    vectorizer = fit_vectorizer(catalogo_sku)
    save_vectorizer_to_s3(vectorizer, resources_bucket_name, prefix_processing_artifacts + "vectorizer/vectorizer.pkl")
    return {
        'statusCode': 200,
        'body': 'Successful Model Training Execution!!!!'
    }