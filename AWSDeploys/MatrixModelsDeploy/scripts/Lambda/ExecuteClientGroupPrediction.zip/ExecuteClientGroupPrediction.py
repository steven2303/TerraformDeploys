import json
import boto3
import os
import time

s3_client = boto3.client('s3')
lambda_client = boto3.client('lambda')
glue_client = boto3.client('glue')

def lambda_handler(event, context):
    bucket_name = os.environ.get('BUCKET_NAME')
    prefix_processing_artifacts = os.environ.get('PREFIX_PROCESSING_ARTIFACTS')
    lambda_arn1 = os.environ.get('LAMBDA_ARN_MODEL1')
    lambda_arn2 = os.environ.get('LAMBDA_ARN_MODEL2')
    lambda_arn3 = os.environ.get('LAMBDA_ARN_NLP_MODEL_TRAINING')
    glue_job_name = os.environ.get('GLUE_JOB')
    file_key = prefix_processing_artifacts + "clients_dictionary/clients_dictionary.json" 
    file_key_full = prefix_processing_artifacts + "clients_dictionary/non_redeeming_clients.json" 

    for record in event['Records']:
        s3_event_data = record
        file_name = s3_event_data['s3']['object']['key']
        # Descarga el archivo JSON desde S3
        response = s3_client.get_object(Bucket=bucket_name, Key=file_key)
        content = response['Body'].read()
        data = json.loads(content)
        if 'catalogo' in file_name.lower():
            reset_s3_json_if_condition(bucket_name, file_key_full)
            group_prediction1 = data['client_model1_current']
            group_prediction2 = data['client_model2_current']
            invoke_params = {
                "FunctionName": lambda_arn3, 
                "InvocationType": "RequestResponse",  
            } 
            response = lambda_client.invoke(**invoke_params)
            response_payload = json.loads(response['Payload'].read().decode('utf-8'))
            message = response_payload.get('body', 'No message returned')
            print(f'Response from invoked Lambda: {message}')
        else:
            new_comb_clients_prediction1 = list(set(data['comb_client_sku_model1_current']) - set(data['comb_client_sku_model1_previous']))
            new_comb_clients_prediction2 = list(set(data['comb_client_sku_model2_current']) - set(data['comb_client_sku_model2_previous']))
            update_clients_prediction1 = [comb[:10] for comb in new_comb_clients_prediction1]
            update_clients_prediction2 = [comb[:10] for comb in new_comb_clients_prediction2]
            ids_clients_prediction1 = list(set(data['client_model1_current']) - set(data['client_model1_previous']))
            ids_clients_prediction2 = list(set(data['client_model2_current']) - set(data['client_model2_previous']))
            group_prediction1 = list(set(update_clients_prediction1 + ids_clients_prediction1))
            group_prediction2 = list(set(update_clients_prediction2 + ids_clients_prediction2))
            
        group_size1 = 600 
        group_size2 = 4500 
        
        groups1 = split_into_groups(group_prediction1, group_size1)
        groups2 = split_into_groups(group_prediction2, group_size2)

        client_ids_dictionary_group1 = create_dictionary(groups1)
        client_ids_dictionary_group2 = create_dictionary(groups2)
        
        print("client_ids_dictionary_group1",client_ids_dictionary_group1.keys())
        print("client_ids_dictionary_group2",client_ids_dictionary_group2.keys())

        print('Iniciando la ejecución de predicciones para clientes que no canjean')
        response = glue_client.start_job_run(JobName=glue_job_name)
        print(f"Iniciada nueva ejecución del trabajo de Glue: {response['JobRunId']}")

        print('Iniciando la ejecución de predicciones para clientes que canjean grupo 1')
        for key, group in client_ids_dictionary_group1.items():
            lambda_client.invoke(
                FunctionName=lambda_arn1,
                InvocationType='Event',
                Payload=json.dumps({"user_ids": group})
            )
            time.sleep(4)

        print('Iniciando la ejecución de predicciones para clientes que canjean grupo 2')
        for key, group in client_ids_dictionary_group2.items():
            lambda_client.invoke(
                FunctionName=lambda_arn2,
                InvocationType='Event',
                Payload=json.dumps({"user_ids": group})
            )
            time.sleep(4)
        
def split_into_groups(lst, group_size):
    groups = []
    for i in range(0, len(lst), group_size):
        groups.append(lst[i:i + group_size])
    return groups

def create_dictionary(groups):
    dictionary = {}
    for i, group in enumerate(groups, start=1):
        key = f"client_id{i}"
        dictionary[key] = group
    return dictionary

def reset_s3_json_if_condition(bucket_name, object_key):
    try:
        # Reset the JSON to its initial state
        non_redeeming_clients_dict = {
            'non_redeeming_clients_current': []
        }
        s3_client.put_object(Bucket=bucket_name, Key=object_key, Body=json.dumps(non_redeeming_clients_dict).encode('utf-8'))
        print(f"JSON file at s3://{bucket_name}/{object_key} has been reset to its initial state.")
        
    except s3_client.exceptions.NoSuchKey:
        # If the JSON does not exist, do nothing
        print(f"JSON file at s3://{bucket_name}/{object_key} does not exist. No action taken.")
