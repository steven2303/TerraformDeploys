import boto3
import json
import pg8000
import os

# Inicializa la conexión fuera del manejador de la función para reutilizarla entre invocaciones
conn = None

def get_db_connection():
    global conn
    secret_id = os.environ.get('SECRETS_MANAGER_SECRET_NAME')

    if conn is None:
        try:
            # Intenta crear una nueva conexión
            secrets_client = boto3.client('secretsmanager')
            secret = secrets_client.get_secret_value(SecretId=secret_id)['SecretString']
            secret_dict = json.loads(secret)
            
            conn_params = {
                "database": secret_dict['DBName'],
                "user": secret_dict['DBUser'],
                "password": secret_dict['DBPassword'],
                "host": secret_dict['DBHost'],
                "port": 5432
            }
            
            conn = pg8000.connect(**conn_params)
        except Exception as e:
            # Maneja errores de conexión
            return None

    return conn

def download_sql_from_s3(bucket_name, file_key):
    s3_client = boto3.client('s3')
    local_file_path = '/tmp/' + file_key
    # Crear subdirectorios si es necesario
    os.makedirs(os.path.dirname(local_file_path), exist_ok=True)
    s3_client.download_file(bucket_name, file_key, local_file_path)
    return local_file_path

def execute_sql_file(conn, file_path):
    with open(file_path, 'r') as file:
        sql_commands = file.read()
    with conn.cursor() as cursor:
        cursor.execute(sql_commands)
        conn.commit()

def lambda_handler(event, context):
    bucket_name = os.environ.get('RESOURCE_BUCKET')
    file_key = os.environ.get('DDL_KEY')

    # Descargar y leer el archivo SQL desde S3
    sql_file_path = download_sql_from_s3(bucket_name, file_key)

    # Conexión a la base de datos
    conn = get_db_connection()
    if conn is None:
        return {
            'statusCode': 500,
            'body': 'Error al conectar con la base de datos'
        }

    # Ejecutar los comandos SQL
    execute_sql_file(conn, sql_file_path)

    return {
        'statusCode': 200,
        'body': 'DDL ejecutado exitosamente'
    }
