import json
import boto3
import os

def lambda_handler(event, context):
    glue_client = boto3.client('glue')
    glue_job_1 = os.environ.get('GLUE_JOB_NAME1')
    glue_job_2 = os.environ.get('GLUE_JOB_NAME2')
    glue_job_3 = os.environ.get('GLUE_JOB_NAME3')

    # Prefijos para determinar el trabajo de Glue a iniciar
    job1_prefixes = json.loads(os.environ.get('PREFIXES_JOB1'))
    job2_prefixes = json.loads(os.environ.get('PREFIXES_JOB2'))
    job3_prefixes = json.loads(os.environ.get('PREFIXES_JOB3'))

    for record in event['Records']:
        s3_event_data = record
        file_name = s3_event_data['s3']['object']['key']
        file_prefix_elements = file_name.split('/')[:2] 
        file_prefix = '/'.join(file_prefix_elements) + '/'

        # Determinar el trabajo de Glue a iniciar
        if file_prefix in job1_prefixes:
            glue_job_name = glue_job_1
        elif file_prefix in job2_prefixes:
            glue_job_name = glue_job_2
        elif file_prefix in job3_prefixes:
            glue_job_name = glue_job_3
        else:
            continue  # Saltar si el prefijo no coincide con ninguno

        # Verificar si el trabajo de Glue específico está en estado 'RUNNING' 
        job_runs = glue_client.get_job_runs(JobName=glue_job_name)
        if any(job_run['JobRunState'] == 'RUNNING' for job_run in job_runs['JobRuns']):
            print(f"El trabajo de Glue {glue_job_name} ya está en ejecución.")
            continue

        # Iniciar el trabajo de Glue
        response = glue_client.start_job_run(JobName=glue_job_name)
        print(f"Iniciada nueva ejecución del trabajo de Glue: {response['JobRunId']}")

    return {
        'statusCode': 200,
        'body': json.dumps('Ejecución del trabajo de Glue iniciada correctamente.')
    }