import pickle
import boto3
import io
import re
import json
import nltk
import csv
import numpy as np
from sklearn.metrics.pairwise import linear_kernel
from nltk.corpus import stopwords
from nltk.stem import SnowballStemmer
import pg8000
import os

# Set up global variables
nltk.data.path.append("/var/task/nltk_data/")
stemmer = SnowballStemmer('spanish')
spanish_stop_words = stopwords.words('spanish')
spanish_stop_words.extend(['&', 'kg', 'lt', '-', 'ml', 'on', 'li', 'l', 'x'])
s3 = boto3.client('s3')

# Global variables for database connection and cursor
db_connection = None
db_cursor = None

# Global variables for vectorizer and data
vectorizer = None
catalogo_sku = None
user_sku = None

# Define the tokenizer function
def load_vectorizer_from_s3(bucket, key):
    global vectorizer
    if vectorizer is None:
        try:
            response = s3.get_object(Bucket=bucket, Key=key)
            pickle_data = io.BytesIO(response['Body'].read())
            vectorizer = pickle.load(pickle_data)
            print("Vectorizer loaded successfully from S3.")
        except Exception as e:
            print(f"Error loading vectorizer: {e}")
    return vectorizer

def read_csv_to_dict(bucket, key, encoding='latin1', delimiter=';'):
    response = s3.get_object(Bucket=bucket, Key=key)
    csv_data = io.BytesIO(response['Body'].read())
    csv_reader = csv.DictReader(io.TextIOWrapper(csv_data, encoding=encoding), delimiter=delimiter)
    return [row for row in csv_reader]

def custom_tokenizer(text):
    tokens = re.findall(r'\b\w+\b', text.lower()) 
    stemmed_tokens = [stemmer.stem(re.sub(r'\d+', '', token)) for token in tokens if token not in spanish_stop_words]
    stemmed_tokens = [token for token in stemmed_tokens if token]
    return stemmed_tokens

def convert_to_records(data_list):
    records = []
    keys = ['cod_persona', 'cod_producto', 'des_canje', 'des_familia']
    for item in data_list:
        # Split the single dictionary key to get the combined value string
        combined_values = list(item.values())[0]
        # Split the values string into a list of individual values
        values = combined_values.split(',')
        # Create a new dictionary by zipping keys with the corresponding values
        record = dict(zip(keys, values))
        records.append(record)
    return records

# Load vectorizer and data globally if they are unlikely to change often
resources_bucket_name = os.environ.get('RESOURCES_BUCKET_NAME')
data_bucket_name = os.environ.get('DATA_BUCKET_NAME')
prefix_sku_catalog = os.environ.get('PREFIX_SKU_CATALOG')
prefix_processing_artifacts = os.environ.get('PREFIX_PROCESSING_ARTIFACTS')
secrets_manager_name = os.environ.get('SECRETS_MANAGER_NAME')

vectorizer = load_vectorizer_from_s3(resources_bucket_name, prefix_processing_artifacts + "vectorizer/vectorizer.pkl")
catalogo_sku = read_csv_to_dict(data_bucket_name, prefix_sku_catalog)
user_sku = read_csv_to_dict(resources_bucket_name, prefix_processing_artifacts + "historical_transactions/historical_transactions.csv")
user_sku = convert_to_records(user_sku)

def generate_content_based_recommendations(user_id, top_n=10):
    redeem_sku = [row for row in user_sku if row['cod_persona'] == user_id]
    for row in redeem_sku:
        row['content'] = row['des_canje'] + ' ' + row['des_familia']
    redeem_sku_content = [row['content'] for row in redeem_sku]
    redeem_sku_id = [row['cod_producto'] for row in redeem_sku]
    redeem_sku_vectors = vectorizer.transform(redeem_sku_content)
    similarity_matrix = np.zeros((len(catalogo_sku),))
    for vector in redeem_sku_vectors:
        content_texts = [row['PRODUCTO'] + ' ' + row['CATEGORIA'] for row in catalogo_sku]
        similarity_matrix += linear_kernel(vector, vectorizer.transform(content_texts)).flatten()
    sorted_indices = np.argsort(similarity_matrix)[::-1]
    return [catalogo_sku[i]['CODIGO'] for i in sorted_indices if catalogo_sku[i]['CODIGO'] not in redeem_sku_id][:top_n]


def get_db_credentials(secret_name):
    client = boto3.client(service_name='secretsmanager')
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)
    
def create_db_connection(secret_dict):
    global db_connection, db_cursor
    try:
        if db_connection is None or db_connection.closed:
            db_connection = pg8000.connect(
                user=secret_dict['DBUser'],
                password=secret_dict['DBPassword'],
                host=secret_dict['DBHost'],
                database=secret_dict['DBName'],
                port=secret_dict.get('DBPort', 5432), 
                timeout=30,  
                application_name="MyApp",  
                ssl_context=None 
            )
            db_cursor = db_connection.cursor()
    except Exception as e:
        print(f"Error creating database connection: {e}")
        db_connection = None
        db_cursor = None

def reset_connection():
    global db_connection, db_cursor
    if db_connection:
        db_cursor.close()
        db_connection.close()
    db_connection, db_cursor = None, None
    secret_dict = get_db_credentials(secrets_manager_name)
    create_db_connection(secret_dict)

def lambda_handler(event, context):
    global db_connection, db_cursor
    
    user_ids = event.get('user_ids', ['0001113070', '0000555562'])
    secret_dict = get_db_credentials(secrets_manager_name)
    create_db_connection(secret_dict)

    if db_cursor:
        try:
            delete_query = "DELETE FROM modelos_matrix.recomendador_clientes WHERE cod_persona = ANY(%s)"
            db_cursor.execute(delete_query, (user_ids,))
            print("DELETE query executed successfully.")

            data = []
            for user_id in user_ids:
                recommendations = generate_content_based_recommendations(user_id, top_n=15)
                row = [user_id] + ['canjea'] + [2] + recommendations
                data.append(row) 
            columns = ['cod_persona'] + ['tip_cliente'] + ["nro_modelo"] + [f'sku_{j}' for j in range(1, 16)]

            columns_sql = ', '.join(columns)
            values_placeholders = ', '.join(['%s'] * len(columns))
            TABLE_NAME = "modelos_matrix.recomendador_clientes"

            insert_query = f"""
            INSERT INTO {TABLE_NAME} ({columns_sql})
            VALUES ({values_placeholders});
            """

            print("Executing INSERT query for this group of clients!")
            data_to_insert = [tuple(row) for row in data]
            db_cursor.executemany(insert_query, data_to_insert)
            db_connection.commit()
            print("INSERT query executed successfully.")
        except pg8000.ProgrammingError as e:
            print(f"ProgrammingError: {e}")
            reset_connection()
        except Exception as e:
            print(f"Error during database operation: {e}")
            reset_connection()

    # Output results
    return {
        'statusCode': 200,
        'body': json.dumps({
            'user_ids': user_ids,
            'recommendations': data
        })
    }
