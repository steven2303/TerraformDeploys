import boto3
import json
import pg8000
import decimal
import os
import datetime

# Inicializa la conexión fuera del manejador de la función para reutilizarla entre invocaciones
conn = None

def get_db_connection():
    global conn
    secret_id = os.environ.get('secrets_manager_secret_name')

    if conn is None:
        try:
            # Intenta crear una nueva conexión
            secrets_client = boto3.client('secretsmanager')
            secret = secrets_client.get_secret_value(SecretId=secret_id)['SecretString']
            secret_dict = json.loads(secret)
            
            conn_params = {
                "database": secret_dict['DBName'],
                "user": secret_dict['DBUser'],
                "password": secret_dict['DBPassword'],
                "host": secret_dict['DBReaderHost'],
                "port": 5432
            }
            
            conn = pg8000.connect(**conn_params)
        except pg8000.InterfaceError:
            # Maneja errores de conexión
            return {
                "headers": {"Content-Type": "application/json"},
                'body': json.dumps({"status": False, "message": str(e), "data": {}})
            }

    return conn

def custom_json_serializer(obj):
    if isinstance(obj, decimal.Decimal):
        return float(obj)  # or str(obj) if you want to avoid floating-point precision issues
    elif isinstance(obj, datetime.datetime):
        return obj.isoformat()  # Converts datetime to ISO format string
    raise TypeError("Type not serializable")

def lambda_handler(event, context):
    try:
        conn = get_db_connection()
        cod_persona = event.get('queryStringParameters', {}).get('cod_persona', None)
        query = f"SELECT * FROM modelos_matrix.recomendador_clientes WHERE cod_persona = '{cod_persona}'"
        
        print(query)
        with conn.cursor() as cursor:
            cursor.execute(query)
            columns = [desc[0] for desc in cursor.description]
            row = cursor.fetchone()
            if row:
                data = dict(zip(columns, row))
                print(data)
                status = True
                message = "OK"
            else:
                data = {}
                status = False
                message = "No existen datos para ese cliente."

        return {
            "headers": {"Content-Type": "application/json"},
            'body': json.dumps({"status": status, "message": message, "data": data}, default=custom_json_serializer)
        }
    except Exception as e:
        return {
            "headers": {"Content-Type": "application/json"},
            'body': json.dumps({"status": False, "message": str(e), "data": {}})
        }