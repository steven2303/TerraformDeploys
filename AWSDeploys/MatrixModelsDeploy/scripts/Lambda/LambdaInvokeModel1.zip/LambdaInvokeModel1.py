import json
import boto3
import pandas as pd
import numpy as np
from io import StringIO, BytesIO
import pg8000
import os

# Initialize S3 client outside the handler
s3 = boto3.client('s3')

# Global variables to store data
data_store = {}
db_connection = None
db_cursor = None

# Define the utility functions
def find_similar_users(user_id, user_sku):
    """ Finds similar users based on their product interactions. """
    dot_product = user_sku.loc[user_id].dot(np.transpose(user_sku))
    most_similar = dot_product.sort_values(ascending=False).index
    return most_similar[most_similar != user_id]

def get_sku_names(sku_codes, df_sku):
    """ Retrieves product names based on SKU codes. """
    return df_sku[df_sku['CODIGO'].isin(sku_codes)]['PRODUCTO'].unique()

def get_user_sku(user_id, user_sku,df_sku):
    """ Retrieves SKUs and their names for a given user. """
    user_products = user_sku.loc[user_id]
    owned_skus = user_products[user_products == 1].index.tolist()
    sku_names = get_sku_names(owned_skus, df_sku)
    return owned_skus, sku_names

def get_top_sorted_users(user_id, df, user_sku):
    """ Ranks users based on similarity and the number of interactions. """
    neighbors_df = pd.DataFrame()
    neighbors_df['neighbor_id'] = find_similar_users(user_id, user_sku)
    # Compute similarity
    neighbors_df['similarity'] = (user_sku.loc[neighbors_df['neighbor_id']].values * user_sku.loc[user_id].values).sum(axis=1)
    num_interactions = df.groupby('cod_persona')['cod_producto'].count().rename('num_interactions')
    neighbors_df = neighbors_df.merge(num_interactions, left_on='neighbor_id', right_index=True, how='left')
    neighbors_df = neighbors_df.sort_values(by=['similarity', 'num_interactions'], ascending=False)
    neighbors_df = neighbors_df[neighbors_df['num_interactions'] <= 24].copy()
    return neighbors_df

def user_user_recs_part(user_id, m=10, df=None, sku_interactions=None, user_sku=None, df_sku=None):
    """ Generates product recommendations for a user based on similar users' interactions. """
    neighbors_df = get_top_sorted_users(user_id, df, user_sku)
    user_skus, _ = get_user_sku(user_id, user_sku,df_sku)
    actual_catalog_sku = get_sku_catalog(df_sku)
    recs = []
    for neighbor_id in neighbors_df['neighbor_id']:
        neighbor_sku, _ = get_user_sku(neighbor_id, user_sku,df_sku)
        new_recs = np.setdiff1d(neighbor_sku, user_skus, assume_unique=True)
        new_recs = np.intersect1d(new_recs, actual_catalog_sku, assume_unique=True)
        sorted_new_recs = sku_interactions.loc[new_recs].sort_values(ascending=False).index.tolist()
        recs.extend(sorted_new_recs)
        recs = list(dict.fromkeys(recs))
        if len(recs) >= m:
            break
    return recs[:m], get_sku_names(recs[:m], df_sku)

def get_sku_catalog(df_sku):
    """ Returns a list of unique SKUs from the catalog. """
    return df_sku['CODIGO'].unique().tolist()

def load_data_from_s3(bucket, key, data_type='parquet'):
    """Utility function to fetch data from S3 and cache it globally."""
    global data_store
    if key not in data_store:
        obj = s3.get_object(Bucket=bucket, Key=key)
        if data_type == 'parquet':
            data_store[key] = pd.read_parquet(BytesIO(obj['Body'].read()))
        else:
            data_store[key] = pd.read_csv(StringIO(obj['Body'].read().decode('latin-1')), sep=';', dtype=str)
    return data_store[key]

def get_db_credentials(secret_name):
    client = boto3.client(service_name='secretsmanager')
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)
    
def create_db_connection(secret_dict):
    global db_connection, db_cursor
    try:
        if db_connection is None or db_connection.closed:
            db_connection = pg8000.connect(
                user=secret_dict['DBUser'],
                password=secret_dict['DBPassword'],
                host=secret_dict['DBHost'],
                database=secret_dict['DBName'],
                port=secret_dict.get('DBPort', 5432), 
                timeout=30,  
                application_name="MyApp",  
                ssl_context=None 
            )
            db_cursor = db_connection.cursor()
    except Exception as e:
        print(f"Error creating database connection: {e}")
        db_connection = None
        db_cursor = None

def reset_connection():
    global db_connection, db_cursor
    if db_connection:
        db_cursor.close()
        db_connection.close()
    db_connection, db_cursor = None, None
    secret_dict = get_db_credentials(secrets_manager_name)
    create_db_connection(secret_dict)

def lambda_handler(event, context): 
    global db_connection, db_cursor
    artifacts_bucket_name = os.environ.get('ARTIFACTS_BUCKET_NAME')
    data_bucket_name = os.environ.get('DATA_BUCKET_NAME')
    prefix_sku_catalog = os.environ.get('PREFIX_SKU_CATALOG')
    prefix_processing_artifacts = os.environ.get('PREFIX_PROCESSING_ARTIFACTS')
    secrets_manager_name = os.environ.get('SECRETS_MANAGER_NAME')
    s3_path_ly = prefix_processing_artifacts + 'current_transactions/current_transactions.parquet'
    s3_path_matrix = prefix_processing_artifacts + 'user_product_interactions/user_product_interactions.parquet'
    TABLE_NAME = "modelos_matrix.recomendador_clientes"

    refresh = event.get('refresh', False)
    
    df_sku = load_data_from_s3(data_bucket_name, prefix_sku_catalog, 'csv') if refresh or prefix_sku_catalog not in data_store else data_store[prefix_sku_catalog]
    user_sku = load_data_from_s3(artifacts_bucket_name, s3_path_matrix) if refresh or s3_path_matrix not in data_store else data_store[s3_path_matrix]
    df_trx_canjes_ly = load_data_from_s3(artifacts_bucket_name, s3_path_ly) if refresh or s3_path_ly not in data_store else data_store[s3_path_ly]

    sku_interactions = df_trx_canjes_ly.groupby('cod_producto').count()['cod_persona']

    secret_dict = get_db_credentials(secrets_manager_name)
    create_db_connection(secret_dict)

    user_ids = event.get('user_ids', ["0002773352", "0003339876", "0005739668"])
    
    delete_query = "DELETE FROM modelos_matrix.recomendador_clientes WHERE cod_persona = ANY(%s)"
    db_cursor.execute(delete_query, (user_ids,))
    
    data = []
    for user_id in user_ids:
        recommendations, product_names = user_user_recs_part(user_id, m=15, df=df_trx_canjes_ly, user_sku=user_sku, sku_interactions = sku_interactions,df_sku=df_sku)
        row = [user_id] + ['canjea'] + [1] + recommendations
        data.append(row) 
    columns = ['cod_persona'] + ['tip_cliente'] + ["nro_modelo"] + [f'sku_{j}' for j in range(1, 16)]

    columns_sql = ', '.join(columns)
    values_placeholders = ', '.join(['%s'] * len(columns))

    insert_query = f"""
    INSERT INTO {TABLE_NAME} ({columns_sql})
    VALUES ({values_placeholders});
    """
    data_to_insert = [tuple(row) for row in data]
    db_cursor.executemany(insert_query, data_to_insert)

    db_connection.commit()
    print('Se inserto exitosamente en la bd!!!!!')
    # Output results
    return {
        'statusCode': 200,
        'body': json.dumps({
            'user_id': user_ids,
            'recommendations': data
        })
    }
