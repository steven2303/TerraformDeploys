import boto3
import pandas as pd
import pg8000
import json
from concurrent.futures import ThreadPoolExecutor
from sqlalchemy import create_engine
from sqlalchemy.pool import QueuePool
from awsglue.utils import getResolvedOptions
import numpy as np
import warnings
import sys
import time
warnings.filterwarnings('ignore', category=pd.errors.PerformanceWarning)

# Define the argument names that you expect to receive from the Glue job
args = ['ARTIFACTS_BUCKET_NAME','DATA_BUCKET_NAME','PREFIX_PROCESSING_ARTIFACTS','SECRET_NAME','PREFIX_SKU_CATALOG','TABLE_NAME']
options = getResolvedOptions(sys.argv, args)

s3_client = boto3.client('s3')
DATA_BUCKET_NAME = options['DATA_BUCKET_NAME']
ARTIFACTS_BUCKET_NAME = options['ARTIFACTS_BUCKET_NAME']
PREFIX_PROCESSING_ARTIFACTS = options['PREFIX_PROCESSING_ARTIFACTS']
SECRET_NAME = options['SECRET_NAME']
PREFIX_SKU_CATALOG = options['PREFIX_SKU_CATALOG']
TABLE_NAME = options['TABLE_NAME']

def get_db_credentials(secret_name):
    client = boto3.client(service_name='secretsmanager')
    get_secret_value_response = client.get_secret_value(SecretId=secret_name)
    secret = get_secret_value_response['SecretString']
    return json.loads(secret)

def create_db_engine(secret_dict, pool_size=10):
    connection_string = f"postgresql+pg8000://{secret_dict['DBUser']}:{secret_dict['DBPassword']}@{secret_dict['DBHost']}/{secret_dict['DBName']}"
    engine = create_engine(connection_string, poolclass=QueuePool, pool_size=pool_size)
    return engine

def insert_batch(batch, engine, insert_query):
    with engine.connect() as conn:
        try:
            conn.execute(insert_query, [tuple(x) for x in batch.values])
        except Exception as e:
            print(f"Error inserting batch: {e}")
            
def delete_records(engine, table_name, codes):
    # Convertir codes a lista si es necesario
    if isinstance(codes, np.ndarray):
        codes = codes.tolist()
    elif not isinstance(codes, list):
        codes = list(codes)
    codes_str = ', '.join([f"'{code}'" for code in codes])
    connection = engine.connect()
    transaction = connection.begin() 
    try:
        delete_query = f"DELETE FROM {table_name} WHERE cod_persona IN ({codes_str})"
        connection.execute(delete_query)
        transaction.commit()  # Commit the transaction if the deletion was successful
        print(f"Successfully deleted records from {table_name}")
    except Exception as e:
        transaction.rollback()  # Rollback the transaction if any error occurs
        print(f"Error deleting records from {table_name}: {e}")
    finally:
        connection.close()

def assign_age_group(edad):
    age_ranges = [
        (10, 30, '10-30'), (31, 35, '31-35'), (36, 40, '36-40'), 
        (41, 45, '41-45'), (46, 50, '46-50'), (51, 55, '51-55'), 
        (56, 60, '56-60'), (61, 65, '61-65'), (66, 70, '66-70'), 
        (71, 75, '71-75')
    ]
    for min_age, max_age, label in age_ranges:
        if min_age <= edad <= max_age:
            return label
    return '>76'

def process_clients_attributes(clients_attr):
    clients_attr['age_range'] = clients_attr['edad'].astype(float).apply(assign_age_group)
    clients_attr["prssex"] = clients_attr["prssex"].astype(str).str.replace('0', '1')
    return clients_attr

def load_clients_dictionary(bucket_name,key_name):
    response = s3_client.get_object(Bucket=bucket_name, Key=key_name)
    content = response['Body'].read()
    clients_dictionary = json.loads(content)
    return clients_dictionary

def separate_redeeming_clients(clients_attr, clients_dictionary):
    redeeming_clients = clients_dictionary['client_model1_current'] + clients_dictionary['client_model2_current']
    non_redeeming_clients = clients_attr[~clients_attr.codperth.isin(redeeming_clients)].copy()
    redeeming_clients_df = clients_attr[clients_attr.codperth.isin(redeeming_clients)].copy()
    return non_redeeming_clients, redeeming_clients_df

def merge_transactions_with_clients(current_transactions, redeeming_clients_df):
    keys_cl = ['codperth', 'prssex', 'age_range', 'dpto', 'prov', 'dist', 'nse', 'estcivcod']
    redeemed_transactions = current_transactions[['cod_persona', 'cod_producto']].merge(redeeming_clients_df[keys_cl], how='left', left_on='cod_persona', right_on='codperth')
    return redeemed_transactions, keys_cl

def generate_aggregated_profiles(merged_transactions, keys):
    n = len(keys)
    for i in range(n):
        key = 'key-' + str(n - i)
        merged_transactions[key] = merged_transactions[keys[:n - i]].apply(lambda row: '_'.join(row.values), axis=1)
        count_group = merged_transactions.groupby(key).cod_persona.count().reset_index().rename(
            columns={'cod_persona': 'num_trx_' + str(n - i)})
        merged_transactions = pd.merge(merged_transactions, count_group, on=key, how='left')
    return merged_transactions
                        
def filter_skus(merged_transactions, sku_catalog):
    skus = sku_catalog.CODIGO.unique()
    return merged_transactions[merged_transactions.cod_producto.isin(skus)].copy()

def identify_reference_keys(merged_transactions):
    key_columns = [f'num_trx_{i}' for i in range(7, 0, -1)]
    merged_transactions['Ref_key'] = (merged_transactions[key_columns] >= 400).idxmax(axis=1).str.replace('num_trx_', 'key-')
    merged_transactions['key_value_f'] = merged_transactions.apply(lambda row: row[row['Ref_key']], axis=1)
    unique_keys = merged_transactions.sort_values('Ref_key', ascending=False)[['Ref_key', 'key_value_f']].drop_duplicates()
    return unique_keys

def calculate_popular_products(merged_transactions, unique_keys):
    results = pd.DataFrame()
    for ref_key, key_value in zip(unique_keys['Ref_key'], unique_keys['key_value_f']):
        filtered_transactions = merged_transactions[merged_transactions[ref_key] == key_value].copy()
        top_products = filtered_transactions['cod_producto'].value_counts().reset_index()[:15][['index']]
        top_products.columns = [key_value]
        results = pd.concat([results, top_products], axis=1)
    results = results.T.reset_index()
    results.columns = ['key', 'sku_1', 'sku_2', 'sku_3', 'sku_4', 'sku_5', 'sku_6', 'sku_7', 'sku_8', 'sku_9', 'sku_10', 'sku_11', 'sku_12', 'sku_13', 'sku_14', 'sku_15']
    return results

def generate_recommendations(non_redeeming_clients,clients_id, keys ,unique_keys, popular_products):
    keys_cl = keys[1:]
    non_redeeming_clients = non_redeeming_clients[keys].fillna('').reset_index(drop=True).copy()#[:1000000]
    non_redeeming_clients = non_redeeming_clients[non_redeeming_clients.codperth.isin(clients_id)].copy()
    n = len(keys_cl)
    for i in range(n):
        non_redeeming_clients['key-' + str(n - i)] = non_redeeming_clients[keys_cl[:n - i]].apply(lambda row: '_'.join(row.values), axis=1)
    unique_codes = unique_keys['key_value_f'].unique()
    m = len(unique_codes)
    for i in range(1, m + 1):
        non_redeeming_clients[f'col{i}'] = unique_codes[i - 1]
    new_columns_data = pd.DataFrame(0, index=non_redeeming_clients.index, columns=[f'comp_comb{i+1}' for i in range(m)])
    for i in range(n):
        for j in range(m):
            key_col = 'key-' + str(n - i)
            col_col = 'col' + str(j + 1)
            new_columns_data[f'comp_comb{j + 1}'] += (non_redeeming_clients[key_col] == non_redeeming_clients[col_col]).astype(int)
    non_redeeming_clients = pd.concat([non_redeeming_clients, new_columns_data], axis=1)
    non_redeeming_clients['Ref_key'] = (new_columns_data == 1).idxmax(axis=1).str.replace('comp_comb', 'col')
    non_redeeming_clients['key_value_f'] = non_redeeming_clients.apply(lambda row: row[row['Ref_key']], axis=1)
    final_recommendations = non_redeeming_clients.merge(popular_products, how='left', left_on='key_value_f', right_on='key')[[
    'codperth', 'sku_1', 'sku_2', 'sku_3', 'sku_4', 'sku_5', 'sku_6', 'sku_7', 'sku_8', 'sku_9', 'sku_10', 'sku_11', 'sku_12', 'sku_13', 'sku_14', 'sku_15']]
    return final_recommendations

def split_into_groups(lst, group_size):
    groups = []
    for i in range(0, len(lst), group_size):
        groups.append(lst[i:i + group_size])
    return groups

def manage_s3_json(bucket_name, object_key):
    try:
        response = s3_client.get_object(Bucket=bucket_name, Key=object_key)
        file_content = response['Body'].read().decode('utf-8')
        data = json.loads(file_content)
    except:
        non_redeeming_clients_dict = {
         'non_redeeming_clients_current':[]
        }
        s3_client.put_object(Bucket=bucket_name, Key=object_key, Body=json.dumps(non_redeeming_clients_dict).encode('utf-8'))
        data = non_redeeming_clients_dict
    return data

def main():
    clients_attr = pd.read_parquet(f's3://{ARTIFACTS_BUCKET_NAME}/{PREFIX_PROCESSING_ARTIFACTS}clients_attr/clients_attr.parquet')
    current_transactions = pd.read_parquet(f's3://{ARTIFACTS_BUCKET_NAME}/{PREFIX_PROCESSING_ARTIFACTS}current_transactions/current_transactions_full.parquet')
    sku_catalog = pd.read_csv(f's3://{DATA_BUCKET_NAME}/{PREFIX_SKU_CATALOG}',sep = ';',encoding = 'latin-1',dtype=str)
    clients_dictionary = load_clients_dictionary(ARTIFACTS_BUCKET_NAME,PREFIX_PROCESSING_ARTIFACTS + "clients_dictionary/clients_dictionary.json")
    clients_attr = process_clients_attributes(clients_attr)
    non_redeeming_clients, redeeming_clients_df = separate_redeeming_clients(clients_attr, clients_dictionary)
    redeemed_transactions, keys = merge_transactions_with_clients(current_transactions, redeeming_clients_df)
    redeemed_transactions = generate_aggregated_profiles(redeemed_transactions, keys[1:])
    redeemed_transactions = filter_skus(redeemed_transactions,sku_catalog)
    unique_keys = identify_reference_keys(redeemed_transactions)
    popular_products = calculate_popular_products(redeemed_transactions, unique_keys)
    non_redeeming_clients_dict = manage_s3_json(ARTIFACTS_BUCKET_NAME,PREFIX_PROCESSING_ARTIFACTS + "clients_dictionary/non_redeeming_clients.json")
    non_redeeming_clients_id = list(set(non_redeeming_clients.codperth.unique()) - set(non_redeeming_clients_dict['non_redeeming_clients_current']))
    groups = split_into_groups(non_redeeming_clients_id, 50000)

    recomendaciones_final = pd.DataFrame()

    if len(groups) != 0:
        for group in groups:
            start_time = time.time()
            recommendations = generate_recommendations(non_redeeming_clients,group,keys,unique_keys, popular_products)
            recomendaciones_final = pd.concat([recomendaciones_final,recommendations])
            end_time = time.time()
            execution_time = end_time - start_time
            print(f"El tiempo de ejecución de las predecciones para este grupo es de {execution_time} segundos.")
            
        recomendaciones_final['tip_cliente'] = 'no canjea'
        recomendaciones_final['nro_modelo'] = 3
        recomendaciones_final = recomendaciones_final.rename(columns = {'codperth':'cod_persona'})[['cod_persona','tip_cliente',
            'nro_modelo','sku_1', 'sku_2', 'sku_3', 'sku_4', 'sku_5', 'sku_6','sku_7', 'sku_8', 'sku_9', 'sku_10', 'sku_11',
            'sku_12', 'sku_13','sku_14', 'sku_15']]
            
        ########################
        secret_dict = get_db_credentials(SECRET_NAME)
        engine = create_db_engine(secret_dict)
        delete_records(engine,TABLE_NAME,non_redeeming_clients_id)
        #########################

        columns = ', '.join(recomendaciones_final.columns)
        values_placeholders = ', '.join(['%s'] * len(recomendaciones_final.columns))
        insert_query = f'INSERT INTO {TABLE_NAME} ({columns}) VALUES ({values_placeholders})'

        batch_size = 5000
        print('Iniciando ingesta de datos')
        with ThreadPoolExecutor(max_workers=10) as executor:
            for i in range(0, len(recomendaciones_final), batch_size):
                batch = recomendaciones_final.iloc[i:i+batch_size]
                executor.submit(insert_batch, batch, engine, insert_query)
    else:
        print('No hay clientes sin canjear sobre los cuales generar recomendaciones!!!')
