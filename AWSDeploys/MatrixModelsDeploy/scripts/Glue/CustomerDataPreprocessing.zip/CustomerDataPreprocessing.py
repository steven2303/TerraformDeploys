import pandas as pd
import boto3
import json
import sys
from pyspark.sql import SparkSession
from pyspark.sql import functions as F
from pyspark.sql import Window
from awsglue.utils import getResolvedOptions

# Define the argument names that you expect to receive from the Glue job
args = ['INPUT_BUCKET_NAME', 'ARTIFACTS_BUCKET_NAME','PREFIX_CANJE', 'PREFIX_DETALLE_CANJE','PREFIX_CLIENTE', 'SECRET_NAME','PREFIX_PROCESSING_ARTIFACTS']

# Get the arguments passed to the script 
options = getResolvedOptions(sys.argv, args)
INPUT_BUCKET_NAME = options['INPUT_BUCKET_NAME']
ARTIFACTS_BUCKET_NAME = options['ARTIFACTS_BUCKET_NAME']
PREFIX_CANJE= options['PREFIX_CANJE']
PREFIX_DETALLE_CANJE = options['PREFIX_DETALLE_CANJE']
PREFIX_CLIENTE = options['PREFIX_CLIENTE']
SECRET_NAME = options['SECRET_NAME']
PREFIX_PROCESSING_ARTIFACTS = options['PREFIX_PROCESSING_ARTIFACTS']

s3_path_matrix = PREFIX_PROCESSING_ARTIFACTS + 'user_product_interactions/user_product_interactions.parquet'
s3_path_hist = PREFIX_PROCESSING_ARTIFACTS + 'historical_transactions/historical_transactions.parquet'
s3_path_hist_csv = PREFIX_PROCESSING_ARTIFACTS + 'historical_transactions/historical_transactions.csv'
s3_path_ly = PREFIX_PROCESSING_ARTIFACTS + 'current_transactions/current_transactions.parquet'
s3_path_clients = PREFIX_PROCESSING_ARTIFACTS + "clients_dictionary/clients_dictionary.json"
s3_path_clients_attrb = PREFIX_PROCESSING_ARTIFACTS + "clients_attr/clients_attr.parquet" 
s3_path_ly_full = PREFIX_PROCESSING_ARTIFACTS + 'current_transactions/current_transactions_full.parquet'

s3 = boto3.client('s3')
spark = SparkSession.builder.appName("Data Processing in Glue").getOrCreate()

def read_parquet_file(path):
    return spark.read.parquet(path)
    
def filter_transactions_by_type(df_transactions, transaction_types):
    return df_transactions.filter(df_transactions["tip_canje"].isin(transaction_types))

def filter_out_non_numeric_entries(df, column_name):
    """Remove entries from DataFrame where specified column is non-numeric."""
    return df.withColumn("is_numeric", F.col(column_name).cast("int").isNotNull()).filter("is_numeric = false")

def process_transactions(df_details, df_transactions):
    df_transactions_filtered = filter_transactions_by_type(df_transactions, ['NORMAL','DELIVERY','DIFERIDO','VENTA DIRECTA'])
    detailed_transactions = df_details.join(df_transactions_filtered, "cod_canje", "right")
    numeric_entries = filter_out_non_numeric_entries(detailed_transactions, "cod_producto").select("cod_producto").distinct()
    filtered_transactions = detailed_transactions.join(numeric_entries, "cod_producto", "left_anti")
    return filtered_transactions

def convert_to_datetime(df, date_column):
    """Convert a specified column of a dataframe to datetime."""
    df[date_column] = pd.to_datetime(df[date_column])
    return df

def filter_transactions_by_date(df, date_column, months=12):
    """Filter transactions to the last 'months' months."""
    max_date = df[date_column].max()
    cutoff_date = max_date - pd.DateOffset(months=months)
    return df[df[date_column] >= cutoff_date].copy(), df[~(df[date_column] >= cutoff_date)].copy()

def drop_duplicates_and_count_interactions(df, person_col, product_col):
    """Drop duplicates and count interactions per person."""
    df = df.drop_duplicates(subset=[person_col, product_col])
    return df, df[person_col].value_counts()

def split_groups_by_interaction_count(interactions, threshold=3):
    """Split personas into two groups based on interaction counts."""
    ids_high = interactions[interactions >= threshold].index.tolist()
    ids_low = interactions[interactions < threshold].index.tolist()
    return ids_high, ids_low

def prepare_final_datasets(df_ly, df_h, ids_high, ids_low, person_col):
    """Prepare the final datasets for analysis."""
    df_group_low = df_ly[df_ly[person_col].isin(ids_low)].copy()
    df_ly = df_ly[df_ly[person_col].isin(ids_high)].copy()
    df_h = df_h[~df_h[person_col].isin(ids_high)].copy()
    df_h = pd.concat([df_h, df_group_low]).reset_index(drop=True)
    return df_ly, df_h.sort_values('fec_transaccion').groupby([person_col, 'cod_producto']).tail(1).sort_values(
        [person_col, 'fec_transaccion']).groupby(person_col).tail(2).sort_values(
        'fec_transaccion', ascending=False).reset_index(drop=True)

def create_interaction_matrix(df, person_col, product_col):
    """Create an interaction matrix from transaction data."""
    user_sku = df.groupby([person_col, product_col])[product_col].count().unstack()
    user_sku = user_sku.fillna(0).astype(int)
    return user_sku.applymap(lambda x: 1 if x >= 1 else 0)

def manage_s3_json(bucket_name, object_key):
    try:
        response = s3.get_object(Bucket=bucket_name, Key=object_key)
        file_content = response['Body'].read().decode('utf-8')
        data = json.loads(file_content)
    except:
        clients_dict = {
         'client_model1_current':[],
         'client_model1_previous':[],
         'client_model2_current':[],
         'client_model2_previous':[],
         'comb_client_sku_model1_current':[],
         'comb_client_sku_model2_current':[],
         'comb_client_sku_model1_previous':[],
         'comb_client_sku_model2_previous':[]
        }
        s3.put_object(Bucket=bucket_name, Key=object_key, Body=json.dumps(clients_dict).encode('utf-8'))
        data = clients_dict
    return data

def main():
    df_det_canje = read_parquet_file(f's3://{INPUT_BUCKET_NAME}/{PREFIX_DETALLE_CANJE}')
    df_canje = read_parquet_file(f's3://{INPUT_BUCKET_NAME}/{PREFIX_CANJE}')
    df_clientes = read_parquet_file(f's3://{INPUT_BUCKET_NAME}/{PREFIX_CLIENTE}') 
    filtered_transactions = process_transactions(df_det_canje,df_canje)
    clients_attr = df_clientes.select(['codperth', 'prssex', 'edad', 'dpto', 'prov', 'dist', 'nse', 'estcivcod'])
    df_clients_attr = clients_attr.toPandas()

    df_trx_canjes = filtered_transactions.toPandas()

    df_trx_canjes = convert_to_datetime(df_trx_canjes, 'fec_transaccion')
    df_trx_canjes_ly, df_trx_canjes_h = filter_transactions_by_date(df_trx_canjes, 'fec_transaccion')
    df_trx_canjes_ly, interactions_ly = drop_duplicates_and_count_interactions(df_trx_canjes_ly, 'cod_persona', 'cod_producto')
    df_trx_canjes_ly[['cod_persona','cod_producto','des_canje','des_familia']].to_parquet(f's3://{ARTIFACTS_BUCKET_NAME}/{s3_path_ly_full}')
    ids_group1, ids_group2 = split_groups_by_interaction_count(interactions_ly)
    df_trx_canjes_ly, df_trx_canjes_h = prepare_final_datasets(df_trx_canjes_ly, df_trx_canjes_h, ids_group1, ids_group2, 'cod_persona')
    df_user_product_matrix = create_interaction_matrix(df_trx_canjes_ly, 'cod_persona', 'cod_producto')

    df_trx_canjes_h[['cod_persona','cod_producto','des_canje','des_familia']].to_parquet(f's3://{ARTIFACTS_BUCKET_NAME}/{s3_path_matrix}')
    df_trx_canjes_h[['cod_persona','cod_producto','des_canje','des_familia']].to_csv(f's3://{ARTIFACTS_BUCKET_NAME}/{s3_path_hist_csv}',index = False)
    df_clients_attr.to_parquet(f's3://{ARTIFACTS_BUCKET_NAME}/{s3_path_clients_attrb}',index = False)
    df_user_product_matrix.to_parquet(f's3://{ARTIFACTS_BUCKET_NAME}/{s3_path_matrix}')
    df_trx_canjes_ly[['cod_persona','cod_producto','des_canje','des_familia']].to_parquet(f's3://{ARTIFACTS_BUCKET_NAME}/{s3_path_ly}')
    clients_dict = manage_s3_json(ARTIFACTS_BUCKET_NAME,s3_path_clients)

    clients_dict['client_model1_previous'] = clients_dict['client_model1_current']
    clients_dict['client_model1_current'] = ids_group1
    clients_dict['client_model2_previous'] = clients_dict['client_model2_current']
    clients_dict['client_model2_current'] = df_trx_canjes_h.cod_persona.unique().tolist()
    clients_dict['comb_client_sku_model1_previous'] = clients_dict['comb_client_sku_model1_current']
    clients_dict['comb_client_sku_model1_current'] = (df_trx_canjes_ly['cod_persona'].astype(str)+df_trx_canjes_ly['cod_producto'].astype(str)).unique().tolist()
    clients_dict['comb_client_sku_model2_previous'] = clients_dict['comb_client_sku_model2_current']
    clients_dict['comb_client_sku_model2_current'] = (df_trx_canjes_h['cod_persona'].astype(str)+df_trx_canjes_h['cod_producto'].astype(str)).unique().tolist()

    s3.put_object(Bucket=ARTIFACTS_BUCKET_NAME, Key=s3_path_clients, Body=json.dumps(clients_dict).encode('utf-8'))