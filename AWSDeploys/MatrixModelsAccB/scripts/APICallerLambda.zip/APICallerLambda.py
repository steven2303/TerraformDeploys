import json
import requests
from requests_aws4auth import AWS4Auth
from urllib.parse import urlencode
import boto3

def lambda_handler(event, context):
    service = 'execute-api'
    region = 'us-west-2'
    url = 'https://kawn9npp34.execute-api.us-west-2.amazonaws.com/dev/products-recommender-and-profile'
    
    # Asumir el rol en la otra cuenta
    sts_client = boto3.client('sts')
    assumed_role_object = sts_client.assume_role(
        RoleArn="arn:aws:iam::577585731673:role/cross-account-654654330879-api-access-role", # Reemplaza con el ARN del rol que deseas asumir
        RoleSessionName="AssumeRoleSession1"
    )
    credentials = assumed_role_object['Credentials']
    
    awsauth = AWS4Auth(credentials['AccessKeyId'], credentials['SecretAccessKey'], region, service, session_token=credentials['SessionToken'])
    
    # Parámetros para la solicitud
    params = {'cod_persona': '354396'}
    query_string = urlencode(params)
    url_with_params = f"{url}?{query_string}"
    
    # Realizar la solicitud
    response = requests.get(url_with_params, auth=awsauth)
    
    # Verificar el resultado
    if response.status_code == 200:
        return {
            'statusCode': 200,
            'body': json.dumps('API invoked successfully!')
        }
    else:
        return {
            'statusCode': response.status_code,
            'body': json.dumps('Failed to invoke API')
        }